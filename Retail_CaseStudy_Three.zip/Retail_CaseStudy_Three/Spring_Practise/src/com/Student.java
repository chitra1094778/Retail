package com;

public class Student {  
private String name;
private int age;
private String gender;
private int mark;
private String grade;
private Address address;
public Student(String name, int age, String gender, int mark, String grade,
		Address address) {
	super();
	this.name = name;
	this.age = age;
	this.gender = gender;
	this.mark = mark;
	this.grade = grade;
	this.address = address;
}

public void studentInfo()
{
	System.out.println("Name "+name +"\nAge  "+age+"\nGender "+gender +"\nMark "+mark +"\nGrade "+grade +"\nAddress "+address.toString());
	
}
public void checkEligible()
{
	if(age>=18)
		System.out.println("Eligible to vote");
	else
		System.out.println("Not Eligible");
}

}