package com;

public class Employee {
	private int id;  
	private String name;  
	private int salary;
	private Address address;//Aggregation  
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	  
	
	public void studentInfo()
	{
		System.out.println("Id " +id +"\nName "+name +"\nSalary "+salary +"\nAddress "+address.toString());
		
	}
	public void checkIT_payer()
	{
		if(salary>=25000)
			System.out.println("Eligible to pay income tax");
		else
			System.out.println("Not Eligible to pay income tax");
	}
	  
	
}
