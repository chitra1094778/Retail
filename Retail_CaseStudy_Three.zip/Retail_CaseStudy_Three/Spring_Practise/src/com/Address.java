package com;

public class Address {
	
	private String add_line;
	private String city;
	private String state;
	public Address(String add_line, String city, String state) {
		
		this.add_line = add_line;
		this.city = city;
		this.state = state;
	}
	@Override
	public String toString(){  
	    return add_line+" " +city+" "+state;  
	}  

}
