package com;

public interface Ishape {

	public abstract double areaOfCircle(int r);

	public abstract double areaOfRectangle(int l , int b);

	public abstract double areaOfTriangle(int b , int h);

}
