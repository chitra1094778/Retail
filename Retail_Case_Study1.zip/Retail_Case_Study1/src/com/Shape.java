package com;
import java.lang.Math;
public class Shape implements Ishape {

	public int a;
	public double areaOfCircle(int r) {
		double area=Math.PI * r *r;
		return area;
	}


	public double areaOfRectangle(int l, int b) {
		double area = l * b; 
		return area;
	}

	public double areaOfTriangle(int b, int h) {

		double area = b * h;
		return area;
	}

	public double areaOfTriangle(int a)
	{
		double area = ((Math.sqrt(3))/4) * a;
		return area;
	}


}

