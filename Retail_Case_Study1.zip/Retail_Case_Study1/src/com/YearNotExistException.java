package com;

@SuppressWarnings("serial")
public class YearNotExistException extends Exception
{
    public String getMessage()
    {
        return "the given year is not a valid year";
    }
}