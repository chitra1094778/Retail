package com;
import java.util.InputMismatchException;
import java.util.Scanner;
public class LeapYear
{

	public static String findLeapYear(int year) throws YearNotExistException
	{
		String result = null;
		if(year > 0)
		{
			if((year % 100 == 0))
			{
				if(year % 400 == 0)
					result = "the given year is leap year";
				else
					result = "the given year is non-leap year";
			}
			else if(year % 4 == 0)
				result = "the given year is leap year";

			else
				result = "the given year is non-leap year";

		}
		else
			throw new YearNotExistException(); 

		return result;
	}
	public static void main(String arg[])
	{
		try
		{
			Scanner s=new Scanner(System.in);
			int year=s.nextInt();
			String answer=LeapYear.findLeapYear(year);
			System.out.println(answer);
		}
		catch(YearNotExistException e)
		{
			System.out.println(e.getMessage());
		}
		catch(InputMismatchException n)
		{
			System.out.println("enter the number");
		}
		finally
		{
			System.out.println("bu bye");
		}
	}
}