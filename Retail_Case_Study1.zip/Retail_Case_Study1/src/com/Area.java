package com;
import java.util.Scanner;
public class Area extends Shape{
	@Override
	public double areaOfTriangle(int b,int a)
	{
		double area = Math.sqrt((a * a) - ((b*b)/4));
		return area;
	}
	public static void main(String[] args) {

		Shape obj1=new Shape();//create an instance to Shape class 
		Shape obj2=new Area();
		Area obj3=new Area();
		Scanner s=new Scanner(System.in);
		System.out.println("enter the radius = ");
		int r=s.nextInt();
		System.out.println("enter the length = ");
		int l=s.nextInt();
		System.out.println("enter the breadth = ");
		int b=s.nextInt();
		System.out.println("enter the height = ");
		int h=s.nextInt();
		System.out.println("enter the sidevalue = ");
		int a=s.nextInt();
		System.out.println("AREA OF CIRCLE "+obj1.areaOfCircle(r));
		System.out.println("AREA OF RECTANGLE "+obj2.areaOfRectangle(l,b));
		System.out.println("AREA OF TRIANGLE "+obj1.areaOfTriangle(b,h));
		System.out.println("AREA OF EQUILATERAL TRIANGLE "+obj3.areaOfTriangle(a));
		System.out.println("AREA OF ISOSCELES "+obj3.areaOfTriangle(b,a));
	}

}
