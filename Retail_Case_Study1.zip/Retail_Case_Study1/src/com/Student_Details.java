package com;
import java.util.*;
import java.util.Map.Entry;
public class Student_Details {

	public ArrayList<Student_Bean> display_ArrayList_Details(ArrayList<Student_Bean> asb)
	{
		ArrayList<Student_Bean> as =new ArrayList<Student_Bean>();
		as.addAll(asb);
		return as;
	}
	public LinkedList<Student_Bean> display_LinkedList_Details(LinkedList<Student_Bean> asb)
	{
		LinkedList<Student_Bean> hs =new LinkedList<Student_Bean>();
		hs.addAll(asb);
		return hs;
	}
	public HashSet<Student_Bean> display_HashSet_Details(HashSet<Student_Bean> asb)
	{
		HashSet<Student_Bean> hset =new HashSet<Student_Bean>();
		hset.addAll(asb);
		return hset;
	}
	public TreeSet<Student_Bean> display_TreeSet_Details(TreeSet<Student_Bean> asb)
	{
		TreeSet<Student_Bean> Tset =new TreeSet<Student_Bean>();
		Tset.addAll(asb);
		return asb;
	}
	public HashMap<Integer,Student_Bean> display_HashMap_Details(HashMap<Integer,Student_Bean> asb)
	{
		HashMap<Integer,Student_Bean> hmap =new HashMap<Integer,Student_Bean>();
		hmap.putAll(asb);
		return hmap;
	}
	public TreeMap<Integer,Student_Bean> display_TreeMap_Details(TreeMap<Integer,Student_Bean> asb)
	{
		TreeMap<Integer,Student_Bean> tmap =new TreeMap<Integer,Student_Bean>();
		tmap.putAll(asb);
		return tmap;
	}
	public static void main(String[] args) {
		Student_Bean sb=new Student_Bean();
		Student_Bean sb1=new Student_Bean();
		Student_Bean sb2=new Student_Bean();
		
		Scanner s=new Scanner(System.in);
		System.out.println("enter the values");
		sb.setId(s.nextInt());
		sb.setName(s.next());
		sb1.setId(s.nextInt());
		sb1.setName(s.next());
		sb2.setId(s.nextInt());
		sb2.setName(s.next());
		Student_Details sd=new Student_Details();
		ArrayList<Student_Bean> as =new ArrayList<Student_Bean>();
		as.add(sb);
		as.add(sb1);
		as.add(sb2);
		ArrayList<Student_Bean> as1=sd.display_ArrayList_Details(as);
		for(Student_Bean bean:as1)
			System.out.println("using arraylist id is "+bean.getId() +" name is "+bean.getName());
		
		LinkedList<Student_Bean> hs =new LinkedList<Student_Bean>();
		hs.addAll(as);
		LinkedList<Student_Bean> hs1 =sd.display_LinkedList_Details(hs);
		for(Student_Bean bean:hs1)
			System.out.println("using linked list id is "+bean.getId() +" name is "+bean.getName());
		
		HashSet<Student_Bean> hset =new HashSet<Student_Bean>();
		hset.addAll(as);
		HashSet<Student_Bean> hset1 =sd.display_HashSet_Details(hset);
		for(Student_Bean bean:hset1)
			System.out.println("using hashset id is "+bean.getId() +" name is "+bean.getName());
		
		TreeSet<Student_Bean> Tset =new TreeSet<Student_Bean>();
		Tset.addAll(as);
		TreeSet<Student_Bean> Tset1=sd.display_TreeSet_Details(Tset);
		for(Student_Bean bean:Tset1)
			System.out.println("using treeset id is "+bean.getId() +" name is "+bean.getName());
		
		HashMap<Integer,Student_Bean> hmap =new HashMap<Integer,Student_Bean>();
		hmap.put(sb.getId(),sb);
		hmap.put(sb1.getId(),sb1);
		hmap.put(sb2.getId(),sb2);
		HashMap<Integer,Student_Bean> hmap1 =sd.display_HashMap_Details(hmap);
		for(Entry<Integer,Student_Bean> bean:hmap1.entrySet())
		System.out.println("using HashMap id is "+bean.getKey() +" name is "+bean.getValue().getName());
		
		
		TreeMap<Integer,Student_Bean> tmap = new TreeMap<Integer,Student_Bean>();
		tmap.put(sb.getId(),sb);
		tmap.put(sb1.getId(),sb1);
		tmap.put(sb2.getId(),sb2);
		TreeMap<Integer,Student_Bean> tmap1=sd.display_TreeMap_Details(tmap);
		for(Entry<Integer,Student_Bean> bean:tmap1.entrySet())
			System.out.println("using TreeMap id is "+bean.getKey() +" name is "+bean.getValue().getName());

		
	}
	
	

}
